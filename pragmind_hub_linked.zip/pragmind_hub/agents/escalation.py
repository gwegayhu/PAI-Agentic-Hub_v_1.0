from config.settings import ESCALATION_PHRASES
from typing import Optional, Tuple


def detect_escalation(text: str) -> Tuple[bool, Optional[str], Optional[str]]:
    """
    Scan agent response text for escalation trigger phrases.

    Returns:
        (triggered, phrase, type)
        - triggered: bool
        - phrase: the exact phrase found (or None)
        - type: one of 'escalation' | 'clarification' | 'anomaly' | 'draft' (or None)
    """
    phrase_type_map = {
        "ESCALATION REQUIRED": "escalation",
        "CLARIFICATION REQUIRED": "clarification",
        "ANOMALY ALERT": "anomaly",
        "DRAFT — REQUIRES PRAGMIND REVIEW": "draft",
    }

    text_upper = text.upper()
    for phrase in ESCALATION_PHRASES:
        if phrase.upper() in text_upper:
            esc_type = phrase_type_map.get(phrase, "escalation")
            return True, phrase, esc_type

    return False, None, None
