"""
PragMind Agentic Hub — FastAPI Application (OpenAI gpt-4o)
==========================================================
Endpoints:
  GET  /health         — Health check + model info
  GET  /agents         — List all 5 agents with metadata
  POST /agents/run     — Run a specific agent directly (bypass router)
  POST /hub/run        — Auto-route to the correct agent via hub graph
"""

import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage

from models.schemas import (
    AgentName,
    ChatMessage,
    RunAgentRequest,
    RunAgentResponse,
    HubRouteRequest,
    HubRouteResponse,
    EscalationFlag,
)
from agents.prompts import AGENT_PROMPTS
from agents.escalation import detect_escalation
from graphs.hub_graph import hub_graph
from config.settings import MODEL_NAME, MAX_TOKENS, FORGE_MAX_TOKENS, FRONTEND_ORIGIN

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# App lifecycle
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("PragMind Agentic Hub starting up...")
    logger.info(f"Model: {MODEL_NAME} | CORS origins: {FRONTEND_ORIGIN}")
    yield
    logger.info("PragMind Agentic Hub shutting down.")


# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------

app = FastAPI(
    title="PragMind Agentic Hub",
    description="Five specialised AI agents — powered by LangGraph + GPT-4o. PragMind AI · Dubai.",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS — allow frontend origin(s) defined in env
origins = [o.strip() for o in FRONTEND_ORIGIN.split(",")]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization"],
)


# ---------------------------------------------------------------------------
# Agent metadata
# ---------------------------------------------------------------------------

AGENT_METADATA = {
    "axiom": {
        "name": "Axiom", "icon": "🧭", "accent": "#4A9EDB",
        "role": "AI Readiness Assessment Agent",
        "mission": "Conducts structured AI Readiness Assessments. Scores maturity across 5 dimensions, produces a prioritised adoption roadmap.",
        "tags": ["AI Strategy", "Consulting", "Discovery"],
    },
    "sage": {
        "name": "Sage", "icon": "🧠", "accent": "#2EC67A",
        "role": "RAG Knowledge Agent",
        "mission": "PragMind's institutional memory. Answers questions using RAG over PragMind's internal knowledge base with full source citations.",
        "tags": ["RAG / LLM", "Internal Knowledge", "LangChain"],
    },
    "atlas": {
        "name": "Atlas", "icon": "📐", "accent": "#E0A835",
        "role": "Proposal Generator",
        "mission": "Converts discovery call notes into fully scoped, technically credible PragMind proposals.",
        "tags": ["AI Consulting", "Proposals", "Pydantic AI"],
    },
    "pulse": {
        "name": "Pulse", "icon": "📊", "accent": "#9B8FF8",
        "role": "Data Insight Narrator",
        "mission": "Transforms data exports into weekly executive insight briefs under 300 words.",
        "tags": ["Data Analytics", "Power BI / Tableau", "Retainer Service"],
    },
    "forge": {
        "name": "Forge", "icon": "⚙️", "accent": "#D17DF5",
        "role": "Agentic Workflow Architect",
        "mission": "Designs complete multi-agent systems — technical architecture, agent specs, inter-agent protocols, deployment blueprints.",
        "tags": ["Agentic Workflows", "LangGraph / CrewAI", "Prompt Engineering"],
    },
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _to_lc_messages(history: list[ChatMessage]) -> list:
    result = []
    for m in history:
        if m.role == "user":
            result.append(HumanMessage(content=m.content))
        else:
            result.append(AIMessage(content=m.content))
    return result


def _esc_flag(triggered: bool, phrase, esc_type) -> EscalationFlag:
    return EscalationFlag(triggered=triggered, phrase=phrase, type=esc_type)


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/health")
async def health():
    return {
        "status": "ok",
        "service": "PragMind Agentic Hub",
        "model": MODEL_NAME,
        "agents": list(AGENT_METADATA.keys()),
    }


@app.get("/agents")
async def list_agents():
    return {"agents": AGENT_METADATA}


@app.post("/agents/run", response_model=RunAgentResponse)
async def run_agent(request: RunAgentRequest):
    """
    Run a specific named agent directly — bypasses the router.
    Pass conversation history for multi-turn context.
    """
    agent_name = request.agent.value
    system_prompt = AGENT_PROMPTS.get(agent_name)
    if not system_prompt:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_name}' not found.")

    max_tok = FORGE_MAX_TOKENS if agent_name == "forge" else MAX_TOKENS
    llm = ChatOpenAI(model=MODEL_NAME, max_tokens=max_tok, temperature=0.3)

    messages = (
        [SystemMessage(content=system_prompt)]
        + _to_lc_messages(request.history)
        + [HumanMessage(content=request.message)]
    )

    try:
        result = llm.invoke(messages)
        response_text = result.content
    except Exception as e:
        logger.error(f"[/agents/run] {agent_name} failed: {e}")
        raise HTTPException(status_code=502, detail=f"Agent call failed: {str(e)}")

    triggered, phrase, esc_type = detect_escalation(response_text)

    return RunAgentResponse(
        agent=request.agent,
        response=response_text,
        escalation=_esc_flag(triggered, phrase, esc_type),
    )


@app.post("/hub/run", response_model=HubRouteResponse)
async def hub_run(request: HubRouteRequest):
    """
    Send a message to the hub. The router classifies and dispatches
    to the appropriate agent automatically.
    """
    lc_history = _to_lc_messages(request.history)
    lc_history.append(HumanMessage(content=request.message))

    initial_state = {
        "messages": lc_history,
        "routed_agent": None,
        "routing_reason": None,
        "response": None,
        "escalation_triggered": False,
        "escalation_phrase": None,
        "escalation_type": None,
    }

    try:
        final_state = hub_graph.invoke(initial_state)
    except Exception as e:
        logger.error(f"[/hub/run] Graph failed: {e}")
        raise HTTPException(status_code=502, detail=f"Hub graph failed: {str(e)}")

    return HubRouteResponse(
        routed_to=AgentName(final_state.get("routed_agent", "axiom")),
        routing_reason=final_state.get("routing_reason", ""),
        response=final_state.get("response", ""),
        escalation=_esc_flag(
            final_state.get("escalation_triggered", False),
            final_state.get("escalation_phrase"),
            final_state.get("escalation_type"),
        ),
    )
