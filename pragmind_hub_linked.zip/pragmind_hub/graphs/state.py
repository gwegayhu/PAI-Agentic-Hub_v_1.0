from typing import Annotated, Optional
from langgraph.graph.message import add_messages
from langchain_core.messages import BaseMessage
from typing_extensions import TypedDict


class HubState(TypedDict):
    """
    Shared state object flowing through the PragMind hub graph.

    Fields:
        messages:       Full conversation history (user + assistant turns).
                        add_messages reducer appends new messages without overwriting.
        routed_agent:   Which of the 5 agents the router selected.
        routing_reason: One-sentence explanation of the routing decision.
        response:       Final string response from the selected agent.
        escalation_triggered: Whether an escalation phrase was found in the response.
        escalation_phrase:    The exact phrase that triggered escalation (if any).
        escalation_type:      Category of the escalation flag.
    """
    messages: Annotated[list[BaseMessage], add_messages]
    routed_agent: Optional[str]
    routing_reason: Optional[str]
    response: Optional[str]
    escalation_triggered: bool
    escalation_phrase: Optional[str]
    escalation_type: Optional[str]
