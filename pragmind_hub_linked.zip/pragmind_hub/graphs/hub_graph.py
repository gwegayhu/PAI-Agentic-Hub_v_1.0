"""
PragMind Agentic Hub — LangGraph Graph (OpenAI gpt-4o)
=======================================================
Architecture:
  START
    └─► router_node         (classifies input → one of 5 agents)
          └─► [conditional edge: routed_agent]
                ├─► axiom_node
                ├─► sage_node
                ├─► atlas_node
                ├─► pulse_node
                └─► forge_node
                      └─► escalation_node   (checks for escalation phrases)
                            └─► END
"""

import json
import logging
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage
from langgraph.graph import StateGraph, START, END

from graphs.state import HubState
from agents.prompts import AGENT_PROMPTS, ROUTER_PROMPT
from agents.escalation import detect_escalation
from config.settings import MODEL_NAME, MAX_TOKENS, FORGE_MAX_TOKENS

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# LLM clients — OpenAI gpt-4o
# ---------------------------------------------------------------------------

_base_llm = ChatOpenAI(model=MODEL_NAME, max_tokens=MAX_TOKENS, temperature=0.3)
_forge_llm = ChatOpenAI(model=MODEL_NAME, max_tokens=FORGE_MAX_TOKENS, temperature=0.3)
_router_llm = ChatOpenAI(model=MODEL_NAME, max_tokens=256, temperature=0.0)


# ---------------------------------------------------------------------------
# Helper: build message list for the LLM call
# ---------------------------------------------------------------------------

def _build_messages(system_prompt: str, state: HubState) -> list:
    msgs = [SystemMessage(content=system_prompt)]
    for m in state["messages"]:
        msgs.append(m)
    return msgs


# ---------------------------------------------------------------------------
# Router node
# ---------------------------------------------------------------------------

def router_node(state: HubState) -> dict:
    """
    Reads the latest user message and routes to the correct agent.
    Uses a lightweight LLM call that returns structured JSON.
    """
    latest_user_msg = ""
    for m in reversed(state["messages"]):
        if isinstance(m, HumanMessage):
            latest_user_msg = m.content
            break

    logger.info(f"[ROUTER] Routing message: {latest_user_msg[:80]}...")

    try:
        result = _router_llm.invoke([
            SystemMessage(content=ROUTER_PROMPT),
            HumanMessage(content=latest_user_msg),
        ])
        raw = result.content.strip()
        # Strip markdown fences if present
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        parsed = json.loads(raw.strip())
        agent = parsed.get("agent", "axiom").lower()
        reason = parsed.get("reason", "Default routing to Axiom.")
    except Exception as e:
        logger.warning(f"[ROUTER] Routing failed ({e}), defaulting to axiom")
        agent = "axiom"
        reason = "Routing error — defaulted to Axiom."

    valid_agents = {"axiom", "sage", "atlas", "pulse", "forge"}
    if agent not in valid_agents:
        agent = "axiom"
        reason = f"Unknown agent '{agent}' returned — defaulted to Axiom."

    logger.info(f"[ROUTER] → {agent.upper()} | {reason}")
    return {"routed_agent": agent, "routing_reason": reason}


# ---------------------------------------------------------------------------
# Agent node factory
# ---------------------------------------------------------------------------

def _make_agent_node(agent_name: str):
    system_prompt = AGENT_PROMPTS[agent_name]
    llm = _forge_llm if agent_name == "forge" else _base_llm

    def agent_node(state: HubState) -> dict:
        logger.info(f"[{agent_name.upper()}] Processing request")
        messages = _build_messages(system_prompt, state)
        try:
            result = llm.invoke(messages)
            response_text = result.content
        except Exception as e:
            logger.error(f"[{agent_name.upper()}] LLM call failed: {e}")
            response_text = f"Agent temporarily unavailable. Please try again.\nError: {str(e)}"

        logger.info(f"[{agent_name.upper()}] Response: {len(response_text)} chars")
        return {
            "response": response_text,
            "messages": [AIMessage(content=response_text)],
        }

    agent_node.__name__ = f"{agent_name}_node"
    return agent_node


axiom_node = _make_agent_node("axiom")
sage_node   = _make_agent_node("sage")
atlas_node  = _make_agent_node("atlas")
pulse_node  = _make_agent_node("pulse")
forge_node  = _make_agent_node("forge")


# ---------------------------------------------------------------------------
# Escalation node
# ---------------------------------------------------------------------------

def escalation_node(state: HubState) -> dict:
    response = state.get("response", "")
    triggered, phrase, esc_type = detect_escalation(response)
    if triggered:
        logger.warning(f"[ESCALATION] '{phrase}' (type={esc_type})")
    return {
        "escalation_triggered": triggered,
        "escalation_phrase": phrase,
        "escalation_type": esc_type,
    }


# ---------------------------------------------------------------------------
# Conditional routing edge
# ---------------------------------------------------------------------------

def route_to_agent(state: HubState) -> str:
    agent = state.get("routed_agent", "axiom")
    node_map = {
        "axiom": "axiom_node",
        "sage":  "sage_node",
        "atlas": "atlas_node",
        "pulse": "pulse_node",
        "forge": "forge_node",
    }
    return node_map.get(agent, "axiom_node")


# ---------------------------------------------------------------------------
# Graph assembly
# ---------------------------------------------------------------------------

def build_hub_graph() -> StateGraph:
    graph = StateGraph(HubState)

    graph.add_node("router_node",    router_node)
    graph.add_node("axiom_node",     axiom_node)
    graph.add_node("sage_node",      sage_node)
    graph.add_node("atlas_node",     atlas_node)
    graph.add_node("pulse_node",     pulse_node)
    graph.add_node("forge_node",     forge_node)
    graph.add_node("escalation_node", escalation_node)

    graph.add_edge(START, "router_node")

    graph.add_conditional_edges(
        "router_node",
        route_to_agent,
        {
            "axiom_node": "axiom_node",
            "sage_node":  "sage_node",
            "atlas_node": "atlas_node",
            "pulse_node": "pulse_node",
            "forge_node": "forge_node",
        },
    )

    for node in ["axiom_node", "sage_node", "atlas_node", "pulse_node", "forge_node"]:
        graph.add_edge(node, "escalation_node")

    graph.add_edge("escalation_node", END)

    return graph.compile()


hub_graph = build_hub_graph()
