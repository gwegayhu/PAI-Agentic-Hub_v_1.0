import os
from dotenv import load_dotenv

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
MODEL_NAME = os.getenv("MODEL_NAME", "gpt-4o")
MAX_TOKENS = int(os.getenv("MAX_TOKENS", "4096"))
FORGE_MAX_TOKENS = int(os.getenv("FORGE_MAX_TOKENS", "8192"))

# Allow comma-separated list of frontend origins for CORS
# e.g. "http://localhost:5500,https://pai-agentic-hub.base44.app"
FRONTEND_ORIGIN = os.getenv("FRONTEND_ORIGIN", "*")

# Escalation phrases to detect in agent responses
ESCALATION_PHRASES = [
    "ESCALATION REQUIRED",
    "CLARIFICATION REQUIRED",
    "ANOMALY ALERT",
    "DRAFT — REQUIRES PRAGMIND REVIEW",
]
